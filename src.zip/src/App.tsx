import React from 'react'
import RegisterRouter from './routers'
import './App.scss'

function App() {
  return <RegisterRouter></RegisterRouter>
}

export default App
