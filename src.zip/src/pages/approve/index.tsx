import React from 'react'
import Review from '../review'
function Approve() {
  return (
    <div>
      <Review role={'admin'} />
    </div>
  )
}

export default Approve
